const { Sequelize, DataTypes } = require("sequelize");
const doenv = require("dotenv");
const db_config = require("../config/.env")
const sql = require("mysql2/promise")

sql.
    createConnection({ user: db_config.process.env.DATABASE_USER, password: db_config.process.env.DATABASE_PASS })
    .then(()=>
    {
        console.log("db CONNECTED successfully")
    })




const sequelize = new Sequelize(
    
    db_config.process.env.DATABASE_USER,
    db_config.process.env.DATABASE_PASS,
    db_config.process.env.DATABASE,{
    host: db_config.process.env.DATABASE_HOST,
    dialect: db_config.process.env.DATABASE_DIALECT,
});

const db={}
db.sequelize=sequelize
db.USER=require("../modals/Entity/user.js")(sequelize,DataTypes)


db.sequelize.sync({ force: false }, () => {

    console.log("Sync done");
  
  });
  

  
  module.exports = db;

console.log('connection successful !!!')