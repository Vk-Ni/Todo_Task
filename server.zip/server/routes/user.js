var express = require('express');
var router = express.Router();
var User = require("../modals/controllers/user");
var Admin = require("../modals/controllers/admin");


///Use routes
router.post("/",User.login);// for creating the user
router.post("/signin",User.create_user);// for creating the user
router.post("/signin",User.isLoggedIn);// for creating the user


//Admin routes
router.post("/",Admin.eventcreation);// for creating the user
router.post("/",Admin.projectallocation);// for creating the user
router.post("/",Admin.publicholiday);// for creating the user